SUJIT KUMAR PATEL — DIGITAL PORTFOLIO

FILES
- index.html     About Me
- blogs.html     Blogs
- projects.html  Technical Projects
- links.html     Links & Accounts and contact form
- style.css      Shared design and responsive layout
- script.js      Mobile navigation and email-based contact form

RUN LOCALLY
1. Extract the ZIP file.
2. Open index.html in a browser.
3. Use the navigation menu to visit all four pages.
4. For a more realistic local server, open the folder in VS Code and use Live Server if installed.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create a new GitHub repository, for example: sujit-portfolio.
2. Upload all five website files to the repository's root folder.
3. Open the repository's Settings > Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Select the main branch and the /(root) folder, then save.
6. Wait for GitHub Pages to publish the site. Copy the live URL it provides.
7. Replace "Live Website Coming Soon" in projects.html with the actual published URL if desired.

BEFORE SUBMISSION
- Confirm the Google Drive resume folder has the correct sharing permissions.
- Check the YouTube, GitHub, and LinkedIn links.
- Confirm the Sales Dashboard repository's actual tools and features before adding specific claims.
- Add the official internship role and real responsibilities before submitting.
- Personalise the blog drafts with your own experiences.
- Test the contact form. It opens the visitor's email application and prepares an email; it does not send messages directly from the website.
- Add a portfolio repository URL only after creating one.

CUSTOMISATION
Edit the HTML files to change text and links. Edit style.css to change colours, fonts, spacing, and layout. Edit script.js to change navigation or form behaviour.
