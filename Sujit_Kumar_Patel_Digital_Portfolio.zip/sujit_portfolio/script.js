// Small interactions shared by all portfolio pages.
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav");

  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.textContent = isOpen ? "✕" : "☰";
    });
  }

  const form = document.querySelector("#contact-form");
  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = document.querySelector("#name").value.trim();
      const email = document.querySelector("#email").value.trim();
      const subject = document.querySelector("#subject").value.trim();
      const message = document.querySelector("#message").value.trim();
      const feedback = document.querySelector("#form-feedback");

      if (!name || !email || !subject || !message) {
        feedback.textContent = "Please complete all fields before continuing.";
        return;
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        feedback.textContent = "Please enter a valid email address.";
        return;
      }

      const mailSubject = encodeURIComponent(subject);
      const mailBody = encodeURIComponent(
        `Name: ${name}\nEmail: ${email}\n\n${message}`
      );
      feedback.textContent = "Your email application should open with the message prepared. Review it and press Send there; this website does not send messages automatically.";
      window.location.href = `mailto:spkumar30092007@gmail.com?subject=${mailSubject}&body=${mailBody}`;
    });
  }
});
